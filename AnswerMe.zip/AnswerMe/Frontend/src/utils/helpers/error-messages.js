export const ERROR_MESSAGES = {
  processosFiltro: 'Erro ao filtrar processos!',
  buscarProcessoId: 'Erro ao buscar o processo pelo ID!'
}
